const sozinmenu = (prefix) => {
	return `

            COMANDOS:


  *Comandos do Sozin:*

➸ *${prefix}loli*
➸ *${prefix}hentai*
➸ *${prefix}dono*
➸ *${prefix}porno*
➸ *${prefix}boanoite*
➸ *${prefix}bomdia*
➸ *${prefix}boatarde*
➸ *${prefix}mia*
➸ *${prefix}mia1*
➸ *${prefix}mia2*
➸ *${prefix}belle*
➸ *${prefix}belle1*
➸ *${prefix}belle2*
➸ *${prefix}belle3*
➸ *${prefix}ayeko*

╔════════════════════
  TRADUZIDO POR *sozin*
  DUVIDAS? 👇
  WA.me/351925955554
╚════════════════════`
}

exports.sozinmenu = Sozinmenu









